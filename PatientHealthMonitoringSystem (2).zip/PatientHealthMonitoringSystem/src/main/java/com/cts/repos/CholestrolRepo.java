package com.cts.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Cholestrol;

public interface CholestrolRepo extends CrudRepository<Cholestrol, Integer> {

}
