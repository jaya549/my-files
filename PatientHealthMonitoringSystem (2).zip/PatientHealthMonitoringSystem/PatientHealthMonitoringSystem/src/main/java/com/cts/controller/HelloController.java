package com.cts.controller;


import java.sql.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
//import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.Patient;
import com.cts.model.radmin;
import com.cts.repos.AdminRepo;
import com.cts.repos.PatientRepo;


@Controller
public class HelloController {
	@Autowired
	private PatientRepo patrepos;
	@Autowired
	private AdminRepo admrepos;
	
@GetMapping(value = {"/Welcome","/"})
public String welcome() {
	// TODO Auto-generated method stub
	return "Welcome";
}
@GetMapping("/doctor")
public String doc() {
	return "Dwelcome";
}
@GetMapping("/patient")
public String pat() {
	return "Pwelcome";
}
@GetMapping("/patient2")
public String pat2() {
	return "Pregister";
}
@GetMapping("/admin")
public String adm() {
	return "Awelcome";
}

@RequestMapping("/Dregister")
public String docwel() {
	return "Dregister";
}



}
