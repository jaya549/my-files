package com.cts.repos;

import org.springframework.data.repository.CrudRepository;


import com.cts.model.Pressure;

public interface PressureRepo extends CrudRepository<Pressure, Integer> {
	

}
