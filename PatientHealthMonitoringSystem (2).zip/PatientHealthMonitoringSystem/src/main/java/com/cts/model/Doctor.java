package com.cts.model;

import java.sql.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



@Entity
public class Doctor {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO , generator = "doctor_sequence")
	private Long did;
	@NotEmpty(message = "Please provide a name")
	private String doctorname;
	
	private Date dob;
	@NotEmpty
	private String gender;
	@Pattern(regexp = "\\d{10}",message = "mobile number should be 10digits")
	@NotEmpty
	private String contactNo;
	@Pattern( message = "password should contain 6 characters and atleast one special character" ,regexp = "^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+])[A-Za-z\\d][A-Za-z\\d!@#$%^&*()_+]{6,19}$")
	private String pwd;
	@NotEmpty
	private String qualification;
	@NotEmpty
	private String spe;
	@NotEmpty
	private String address;
	@NotEmpty
	private String question;
	@NotEmpty
	private String answer;
	
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	//@OneToMany(mappedBy = "doctor")
	//private Set<Patient> patients;
	public Long getDid() {
		return did;
	}
	public void setDid(Long did) {
		this.did = did;
	}
	public String getDoctorname() {
		return doctorname;
	}
	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getSpe() {
		return spe;
	}
	public void setSpe(String spe) {
		this.spe = spe;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Doctor [did=" + did + ", doctorname=" + doctorname + ", dob=" + dob + ", gender=" + gender
				+ ", contactNo=" + contactNo + ", pwd=" + pwd + ", qualification=" + qualification + ", spe=" + spe
				+ ", address=" + address + "]";
	}
	public Doctor(Long did, @NotEmpty(message = "Please provide a name") String doctorname, Date dob, String gender,
			String contactNo, String pwd, String qualification, String spe, String address) {
		super();
		this.did = did;
		this.doctorname = doctorname;
		this.dob = dob;
		this.gender = gender;
		this.contactNo = contactNo;
		this.pwd = pwd;
		this.qualification = qualification;
		this.spe = spe;
		this.address = address;
	}
	public Doctor() {
		super();
	}
	
	

}
