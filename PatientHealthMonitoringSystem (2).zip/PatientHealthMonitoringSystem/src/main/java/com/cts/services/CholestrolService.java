package com.cts.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Cholestrol;
import com.cts.repos.CholestrolRepo;



@Service
@Transactional
public class CholestrolService {
	@Autowired
	private CholestrolRepo cholestrolrepo;
	public void register(Cholestrol cholestrol) {
		cholestrolrepo.save(cholestrol);
	}
	public List<Cholestrol> showAll() {
		List<Cholestrol> patients= (List<Cholestrol>) cholestrolrepo.findAll();
		return patients;
		
	}

}
