package com.cts.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Caloriestracker;

public interface CalTrackRepo extends CrudRepository<Caloriestracker, Integer> {

}
