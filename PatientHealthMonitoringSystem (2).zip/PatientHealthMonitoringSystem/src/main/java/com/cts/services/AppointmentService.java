package com.cts.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Appointment;

import com.cts.repos.AppRepo;


@Service
public class AppointmentService {
	@Autowired
	private AppRepo apprepos;
	public void register(Appointment appointment) {
		apprepos.save(appointment);
	}
	public List<Appointment> showAllAppointments(String doctorname) {
		List<Appointment> xyz= (List<Appointment>) apprepos.findByDoctorname(doctorname);
		 Date date = Calendar.getInstance().getTime();  
         DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  
         String strDate = dateFormat.format(date);  
         List<Appointment>patients=new ArrayList<Appointment>();
         for (Appointment appointment : xyz) {
        	 String bdate=appointment.getTime();
        	 
        	 if(bdate.compareTo(strDate)>=0) {
        		 patients.add(appointment);
        	 }
			
		}
		return patients;
		
	}

}
