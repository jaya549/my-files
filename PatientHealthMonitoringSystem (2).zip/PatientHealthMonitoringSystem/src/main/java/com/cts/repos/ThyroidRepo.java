package com.cts.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Thyroid;

public interface ThyroidRepo extends CrudRepository<Thyroid, Integer> {

}
