package com.cts.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Thyroid;
import com.cts.repos.ThyroidRepo;



@Service
@Transactional
public class ThyroidService {
	@Autowired
	private ThyroidRepo thyroidrepos;
	public void register(Thyroid thyroid) {
		thyroidrepos.save(thyroid);
	}
	public List<Thyroid> showAll() {
		List<Thyroid> patients= (List<Thyroid>) thyroidrepos.findAll();
		return patients;
		
	}

}
