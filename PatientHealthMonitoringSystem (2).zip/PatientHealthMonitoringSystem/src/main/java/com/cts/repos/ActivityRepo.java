package com.cts.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Activitytracker;


public interface ActivityRepo  extends CrudRepository<Activitytracker,Integer>{

}
