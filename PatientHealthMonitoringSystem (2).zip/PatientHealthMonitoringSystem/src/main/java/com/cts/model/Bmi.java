package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Bmi {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator="bmi_sequence")
	private int bmiid;
	private int height;
	private int weight;
	private long patientid;
	private float bmi;
	public int getBmiid() {
		return bmiid;
	}
	public void setBmiid(int bmiid) {
		this.bmiid = bmiid;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public long getPatientid() {
		return patientid;
	}
	public void setPatientid(long patientid) {
		this.patientid = patientid;
	}
	public float getBmi() {
		return bmi;
	}
	public void setBmi(float bmi) {
		this.bmi = bmi;
	}
	public Bmi() {
		super();
	}
	

}
