package com.cts.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cts.model.Caloriestracker;
import com.cts.repos.CalTrackRepo;

@Service
@Transactional
public class CaloriesTrackerService {
	@Autowired
	private CalTrackRepo calrepos;
	public void register(Caloriestracker calories) {
		calrepos.save(calories);
	}
	public List<Caloriestracker> showAll() {
		List<Caloriestracker> patients= (List<Caloriestracker>) calrepos.findAll();
		return patients;
		
	}

}
