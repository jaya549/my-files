package com.cts.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Diettracker {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO,generator = "diet_sequence")
    private int diettrackerId;
    private Long patientid;
    private String date;
    private String diet;
    private String time;
     @ManyToOne
        @JoinColumn( name="patientid", insertable=false, updatable=false)
        private Patient patient;
     public Patient getPatient() {
         return patient;
     }
     public void setPatient(Patient patient) {
         this.patient = patient;
     }
    public Diettracker() {
        super();
    }
    public Diettracker(int diettrackerId, Long patientid, String date, String diet, String time, Patient patient) {
        super();
        this.diettrackerId = diettrackerId;
        this.patientid = patientid;
        this.date = date;
        this.diet = diet;
        this.time = time;
        this.patient = patient;
    }
    public int getDiettrackerId() {
        return diettrackerId;
    }
    public void setDiettrackerId(int diettrackerId) {
        this.diettrackerId = diettrackerId;
    }
    public Long getPatientid() {
        return patientid;
    }
    public void setPatientid(Long patientid) {
        this.patientid = patientid;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getDiet() {
        return diet;
    }
    public void setDiet(String diet) {
        this.diet = diet;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    @Override
    public String toString() {
        return "Diettracker [diettrackerId=" + diettrackerId + ", patientId=" + patientid + ", diet=" + diet + ", time="
                + time + "]";
    }
}