package com.cts.model;

 

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Cholestrol {
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO,generator = "cholestrol_sequence")
    private int cholestrolId;
    private Long patientid;
    private String time;
    private String date;
    public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}
	private String cholestrolLevel;
     @ManyToOne
        @JoinColumn( name="patientid", insertable=false, updatable=false)
        private Patient patient;
     
     public Cholestrol() {
            super();
        }
    
    



	@Override
	public String toString() {
		return "Cholestrol [cholestrolId=" + cholestrolId + ", patientid=" + patientid + ", time=" + time + ", date="
				+ date + ", cholestrolLevel=" + cholestrolLevel + ", patient=" + patient + "]";
	}


	public Cholestrol(int cholestrolId, Long patientid, String date,String time, String cholestrolLevel, Patient patient) {
		super();
		this.cholestrolId = cholestrolId;
		this.patientid = patientid;
		this.time = time;
		this.cholestrolLevel = cholestrolLevel;
		this.patient = patient;
		this.date = date;
	}




	public String getTime() {
		return time;
	}




	public void setTime(String time) {
		this.time = time;
	}




	public int getCholestrolId() {
		return cholestrolId;
	}


	public void setCholestrolId(int cholestrolId) {
		this.cholestrolId = cholestrolId;
	}


	public Long getPatientid() {
		return patientid;
	}


	public void setPatientid(Long patientid) {
		this.patientid = patientid;
	}


	public Patient getPatient() {
		return patient;
	}


	public void setPatient(Patient patient) {
		this.patient = patient;
	}


	
    public String getCholestrolLevel() {
        return cholestrolLevel;
    }
    public void setCholestrolLevel(String cholestrolLevel) {
        this.cholestrolLevel = cholestrolLevel;
    }
	
    

 

}