package com.cts.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Bmi;

public interface bmirepos extends CrudRepository<Bmi, Integer> {

}
