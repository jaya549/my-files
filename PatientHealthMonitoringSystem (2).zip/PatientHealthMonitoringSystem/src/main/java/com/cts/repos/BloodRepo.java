package com.cts.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Blood;

public interface BloodRepo extends CrudRepository<Blood, Integer> {
	

}
