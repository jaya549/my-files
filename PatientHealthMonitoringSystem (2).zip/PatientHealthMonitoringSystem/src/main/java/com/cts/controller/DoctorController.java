package com.cts.controller;



import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.Appointment;

import com.cts.model.Doctor;
import com.cts.model.MedicalRecord;
import com.cts.model.Patient;

import com.cts.services.AppointmentService;
import com.cts.services.DoctorService;
import com.cts.services.MedicalService;
import com.cts.services.PatientService;
@Controller
public class DoctorController {
	@Autowired
	private DoctorService doctorservice;
	@Autowired
	private PatientService patientservice;
	@Autowired
	private MedicalService medicalservice;
	@Autowired
	private AppointmentService appointmentservice;
	
	@GetMapping("/Dregister")
	public String docwelc(Model m) {
		Doctor doctor =new Doctor();		m.addAttribute("doctor",doctor);
		return "Dregister";
	}
	@PostMapping( "/Dregister" )
	public String regfom(@Valid @ModelAttribute("doctor") Doctor doctor, BindingResult br,Model m){
		if(br.hasErrors()) {
			return "Dregister";
		}
		doctorservice.register(doctor);
		m.addAttribute("successpage","Registered Successfully ");
		return "successpage";

	}
	@GetMapping("/Dlogin")
	public String doclog() {
		return "Dlogin";
	}
	@RequestMapping("/dsuccess/{username}")
	public String dsuc(@PathVariable("username") String doctorname,Model m,HttpSession session) {
		session.setAttribute("doctorname", doctorname);
		m.addAttribute("username",doctorname);
		return "dsuccesspage";
	}
	@PostMapping("/Dlogin" )
	public String dl(@RequestParam("username") String firstname, Model m, @RequestParam("password") String password,HttpSession session)
	{
		Doctor d=doctorservice.login(firstname, password);
		if (!(ObjectUtils.isEmpty(d))) {
			m.addAttribute("successpage", "Login Successful");
			m.addAttribute("username",firstname);
			m.addAttribute("doctor",d);
			m.addAttribute("qualification",d.getQualification());
			session.setAttribute("username", firstname);
			return "dsuccesspage";
		}
		return "Dunsucess";
	}		
	@GetMapping("/dforget")
	public String forget() {
		return "doctorforgetid";
	}
	@GetMapping("/dforgetpassword")
	public String forgetpassword() {
		return "doctorforgetpassword";
	}
	@PostMapping("/dforgetpassword")
	public String forgetpassword(Model m,@RequestParam("question") String question,@RequestParam("answer") String answer,@RequestParam("contactNo") String contact) {
		String password=doctorservice.findpassword(question,answer,contact );
		if(password!=null) {
		m.addAttribute("successpage",password);
		return "successpage";
		}
		return "Dunsucess";
		
	}
	@PostMapping("/dforget")
	public String ques(Model m,@RequestParam("question") String question,@RequestParam("answer") String answer) {
		String userid=doctorservice.findid(question,answer);
		if(userid!=null)
		{
			m.addAttribute("successpage",userid);
			return "successpage";
		}
		
			return "Dunsucess";
		
	}
	@RequestMapping("/applist/{username}")
	public String lop(Model m,@PathVariable("username") String doctorname) {
		List<Patient> patients=patientservice.showAllpatients();
		//patients.stream().forEach(System.out::println);
		
		m.addAttribute("patients",patients);
		return "lop";
	}
	
	@RequestMapping("/detail/{patient.patientid}")
	public String medrec(@PathVariable("patient.patientid")Long patientid,Model m) {
		m.addAttribute("patientid",patientid);
		MedicalRecord medrec=new MedicalRecord();
		m.addAttribute("medrec",medrec);
		return "medicalform";
	}
	
	
	@RequestMapping("/mybooking/{username}")
	public String books(Model m,@PathVariable("username") String doctorname) {
		List<Appointment> appointments=appointmentservice.showAllAppointments(doctorname);
		//patients.stream().forEach(System.out::println);
		m.addAttribute("appointments",appointments);
		return "loa";
	}
	@RequestMapping("/medsave")
	public String medsave(@Valid@ModelAttribute("medrec") MedicalRecord medicalrecord) {
		medicalservice.register(medicalrecord);	
		return "dsave";
	}
	@RequestMapping("/doclist")
	public String doctors(Model m) {
		List<Doctor> doctors=doctorservice.findall();
		m.addAttribute("doctors",doctors);
		return "listofdoctors";
		
	}
	
		

}
