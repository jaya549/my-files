package com.cts.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Patient;

public interface PatientRepo extends CrudRepository<Patient, Long> {

	Patient findByFirstnameAndPassword(String firstname, String password);

}
