package com.cts.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Caloriestracker {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO,generator = "calories_sequence")
    private int caloriestrackerId;
    private Long patientid;
    private String date;
    private int calories;
    private String time;
     @ManyToOne
        @JoinColumn( name="patientid", insertable=false, updatable=false)
        private Patient patient;
     public Patient getPatient() {
         return patient;
     }
     public void setPatient(Patient patient) {
         this.patient = patient;
     }
    public Caloriestracker() {
        super();
    }
    public Caloriestracker(int caloriestrackerId, Long patientid, String date, int calories, String time,
            Patient patient) {
        super();
        this.caloriestrackerId = caloriestrackerId;
        this.patientid = patientid;
        this.date = date;
        this.calories = calories;
        this.time = time;
        this.patient = patient;
    }
    public int getCaloriestrackerId() {
        return caloriestrackerId;
    }
    public void setCaloriestrackerId(int caloriestrackerId) {
        this.caloriestrackerId = caloriestrackerId;
    }
    public Long getPatientid() {
        return patientid;
    }
    public void setPatientid(Long patientid) {
        this.patientid = patientid;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public int getCalories() {
        return calories;
    }
    public void setCalories(int calories) {
        this.calories = calories;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    @Override
    public String toString() {
        return "Caloriestracker [caloriestrackerId=" + caloriestrackerId + ", patientid=" + patientid + ", calories="
                + calories + ", time=" + time + "]";
    }
}