package com.cts.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Doctor;

public interface DoctorRepo extends CrudRepository<Doctor, Long> {

	Doctor findByDoctornameAndPwd(String firstname, String password);

	Doctor findByQuestionAndAnswer(String question, String answer);

	Doctor findByContactNo(String contact);

}
