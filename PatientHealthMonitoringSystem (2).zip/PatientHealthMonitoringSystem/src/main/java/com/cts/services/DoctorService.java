package com.cts.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.cts.model.Doctor;
import com.cts.model.Patient;
import com.cts.repos.DoctorRepo;

@Service
@Transactional
public class DoctorService {
	@Autowired
	private DoctorRepo docrepos;
	
	public void register(Doctor doctor) {
		docrepos.save(doctor);
	}

	public List<Doctor> showAllDoctors(){
		List<Doctor> doctors = new ArrayList<Doctor>();
		for(Doctor doctor : docrepos.findAll()) {
			doctors.add(doctor);
		}
		
		return doctors;
	}
	public Doctor login(String firstname,String password) {
		return docrepos.findByDoctornameAndPwd(firstname, password);
	}

	public String findid(String question, String answer) {
		Doctor d=docrepos.findByQuestionAndAnswer(question,answer);
		if(!(ObjectUtils.isEmpty(d))) {
		return d.getDoctorname();
	}
		else {
			return null;
		}
	}

	public String findpassword(String question, String answer, String contact) {
		Doctor d=docrepos.findByQuestionAndAnswer(question,answer);
		if(!(ObjectUtils.isEmpty(d))) {
			Doctor d2=docrepos.findByContactNo(contact);
			if(d.equals(d2)) {
				return d2.getPwd();
			}
			
			
		}
		
			return null;
		
	}

	public List<Doctor> findall() {
		List<Doctor> doctors = (List<Doctor>) docrepos.findAll();
		
		return doctors;
	}
	
}
