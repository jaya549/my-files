package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotEmpty;

@Entity
public class MedicalRecord {
	
	
	@Id
	private Long patientid;
	@NotEmpty(message = "please suggest a medicine")
	private String prescription;
	private String date;
	@ManyToOne
	@JoinColumn(name = "patientid", insertable=false, updatable=false)
	private Patient patient;
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getPrescription() {
		return prescription;
	}
	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}
	public Long getPatientid() {
		return patientid;
	}
	public void setPatientid(Long patientid) {
		this.patientid = patientid;
	}
	
	
	public MedicalRecord() {
		super();
	}
	public MedicalRecord(String prescription, Long patientid) {
		super();
		this.prescription = prescription;
		this.patientid = patientid;
	}
	@Override
	public String toString() {
		return "MedicalRecord [prescription=" + prescription + ", patientid=" + patientid + "]";
	}
	

}
