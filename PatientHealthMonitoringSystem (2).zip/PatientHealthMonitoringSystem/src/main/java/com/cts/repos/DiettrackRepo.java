package com.cts.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Diettracker;

public interface DiettrackRepo extends CrudRepository<Diettracker, Integer> {

}
