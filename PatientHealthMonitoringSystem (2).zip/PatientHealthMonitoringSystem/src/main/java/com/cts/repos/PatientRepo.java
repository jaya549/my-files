package com.cts.repos;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Patient;

public interface PatientRepo extends CrudRepository<Patient, Long> {

	Patient findByFirstnameAndPassword(String firstname, String password);

	

	List<Patient> findByDoctorname(String doctorname);



	Patient findByPatientid(Long id);



	Patient findByQuestionAndAnswer(String question, String answer);



	Patient findByContact(String contact);

}
