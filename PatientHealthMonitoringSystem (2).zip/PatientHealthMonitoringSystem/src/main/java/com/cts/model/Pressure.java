package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Pressure {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "pressure_sequence")
	private int pressureid;
	private Long patientid;
	private String time ;
	private String pressureLevel;
	@ManyToOne
	@JoinColumn(name = "patientid",insertable=false, updatable=false)
	private Patient patient;
	public int getPressureid() {
		return pressureid;
	}
	public void setPressureid(int pressureid) {
		this.pressureid = pressureid;
	}
	public Long getPatientid() {
		return patientid;
	}
	public void setPatientid(Long patientid) {
		this.patientid = patientid;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	
	
	@Override
	public String toString() {
		return "Pressure [pressureid=" + pressureid + ", patientid=" + patientid + ", time=" + time + ", pressureLevel="
				+ pressureLevel + ", patient=" + patient + "]";
	}
	public Pressure(int pressureid, Long patientid, String time, String pressureLevel, Patient patient) {
		super();
		this.pressureid = pressureid;
		this.patientid = patientid;
		this.time = time;
		this.pressureLevel = pressureLevel;
		this.patient = patient;
	}
	public String getPressureLevel() {
		return pressureLevel;
	}
	public void setPressureLevel(String pressureLevel) {
		this.pressureLevel = pressureLevel;
	}
	public Pressure() {
		super();
	}
	
	

}
