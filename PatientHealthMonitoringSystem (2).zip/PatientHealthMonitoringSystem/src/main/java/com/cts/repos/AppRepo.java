package com.cts.repos;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Appointment;


public interface AppRepo extends CrudRepository<Appointment, Long> {

	List<Appointment> findByDoctorname(String doctorname);

}
