package com.cts.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Activitytracker {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO , generator = "activity_sequence")
    private int activitytrackerId;
    private Long patientid;
    private String date;
    private String activity;
    private String time;
     @ManyToOne
        @JoinColumn( name="patientid", insertable=false, updatable=false)
        private Patient patient;
     public Patient getPatient() {
         return patient;
     }
     public void setPatient(Patient patient) {
         this.patient = patient;
     }
    public Activitytracker() {
        super();
    }
    public Activitytracker(int activitytrackerId, Long patientid, String date, String activity, String time,
            Patient patient) {
        super();
        this.activitytrackerId = activitytrackerId;
        this.patientid = patientid;
        this.date = date;
        this.activity = activity;
        this.time = time;
        this.patient = patient;
    }
    public int getActivitytrackerId() {
        return activitytrackerId;
    }
    public void setActivitytrackerId(int activitytrackerId) {
        this.activitytrackerId = activitytrackerId;
    }
    public Long getPatientid() {
        return patientid;
    }
    public void setPatientid(Long patientid) {
        this.patientid = patientid;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getActivity() {
        return activity;
    }
    public void setActivity(String activity) {
        this.activity = activity;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    @Override
    public String toString() {
        return "Activitytracker [activitytrackerId=" + activitytrackerId + ", patientid=" + patientid + ", activity="
                + activity + ", time=" + time + "]";
    }
    }