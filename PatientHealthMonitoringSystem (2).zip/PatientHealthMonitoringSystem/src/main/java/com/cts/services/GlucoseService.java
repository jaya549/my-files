package com.cts.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cts.model.Glucose;
import com.cts.repos.GlucoseRepo;

@Service
@Transactional
public class GlucoseService {

	@Autowired
	private GlucoseRepo glurepos;
	public void register(Glucose glucose) {
		glurepos.save(glucose);
	}
	public List<Glucose> showAll() {
		List<Glucose> patients= (List<Glucose>) glurepos.findAll();
		return patients;
		
	}
}
