package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Glucose {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "glucose_sequence")
	private int glucoseid;
	private Long patientid;
	public Long getPatientid() {
		return patientid;
	}
	public void setPatientid(Long patientid) {
		this.patientid = patientid;
	}
	private String glucoselevel;
	private String time;
	@ManyToOne
	@JoinColumn( name="patientid", insertable=false, updatable=false)
	private Patient patient;
	public int getGlucoseid() {
		return glucoseid;
	}
	public void setGlucoseid(int glucoseid) {
		this.glucoseid = glucoseid;
	}
	public String getGlucoselevel() {
		return glucoselevel;
	}
	public void setGlucoselevel(String glucoselevel) {
		this.glucoselevel = glucoselevel;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	
	public Glucose() {
		super();
	}
	public Glucose(int glucoseid, Long patientid, String glucoselevel, String time, Patient patient) {
		super();
		this.glucoseid = glucoseid;
		this.patientid = patientid;
		this.glucoselevel = glucoselevel;
		this.time = time;
		this.patient = patient;
	}
	@Override
	public String toString() {
		return "Glucose [glucoseid=" + glucoseid + ", patientid=" + patientid + ", glucoselevel=" + glucoselevel
				+ ", time=" + time + ", patient=" + patient + "]";
	}
	
	
	
}
