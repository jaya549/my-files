package com.cts.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Bmi;

import com.cts.repos.bmirepos;
@Service
@Transactional
public class BmiService {
	@Autowired
	private bmirepos bmirepo;
	public void register(Bmi bmi) {
		int a=bmi.getHeight();
		int b=bmi.getWeight();
		float rec=(b/(a*a/(100*100)));
		bmi.setBmi(rec);
		System.out.println(rec);
		bmirepo.save(bmi);
	}
	public List<Bmi> showAll() {
		List<Bmi> patients= (List<Bmi>) bmirepo.findAll();
		return patients;
		
	}
}
