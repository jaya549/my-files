package com.cts.model;

 

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Thyroid {
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO,generator = "thyroid_sequence")
    private int thyroidId;
    private Long patientid;
    private String time;
    private String date;
    private String thyroidLevel;
     @ManyToOne
        @JoinColumn( name="patientid", insertable=false, updatable=false)
        private Patient patient;
	public int getThyroidId() {
		return thyroidId;
	}
	public void setThyroidId(int thyroidId) {
		this.thyroidId = thyroidId;
	}
	public Long getPatientid() {
		return patientid;
	}
	public void setPatientid(Long patientid) {
		this.patientid = patientid;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getThyroidLevel() {
		return thyroidLevel;
	}
	public void setThyroidLevel(String thyroidLevel) {
		this.thyroidLevel = thyroidLevel;
	}
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	public Thyroid(int thyroidId, Long patientid, String time, String date, String thyroidLevel, Patient patient) {
		super();
		this.thyroidId = thyroidId;
		this.patientid = patientid;
		this.time = time;
		this.date = date;
		this.thyroidLevel = thyroidLevel;
		this.patient = patient;
	}
	public Thyroid() {
		super();
	}
	@Override
	public String toString() {
		return "Thyroid [thyroidId=" + thyroidId + ", patientId=" + patientid + ", time=" + time + ", date=" + date
				+ ", thyroidLevel=" + thyroidLevel + ", patient=" + patient + "]";
	}
     
    
    

 

}