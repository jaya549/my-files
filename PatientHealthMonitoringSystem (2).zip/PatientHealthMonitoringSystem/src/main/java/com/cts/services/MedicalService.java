package com.cts.services;

import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.MedicalRecord;
import com.cts.repos.MedicalRepo;



@Service
@Transactional
public class MedicalService {
	@Autowired
	private MedicalRepo medrepos;
	public void register(MedicalRecord medical) {
		medrepos.save(medical);
	}
	public List<MedicalRecord> showAll() {
		List<MedicalRecord> patients= (List<MedicalRecord>) medrepos.findAll();
		return patients;
		
	}
	public MedicalRecord findByPatientid(Long id) {
		return medrepos.findById(id).get();
		
		
	}

}
