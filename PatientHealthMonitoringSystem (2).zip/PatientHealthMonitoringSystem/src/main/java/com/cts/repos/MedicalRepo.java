package com.cts.repos;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.MedicalRecord;

public interface MedicalRepo extends CrudRepository<MedicalRecord, Long> {

	MedicalRecord findByPatientid(Long id);

	
	
}
