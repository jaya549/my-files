package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.Patient;
import com.cts.model.radmin;
import com.cts.repos.AdminRepo;
import com.cts.repos.PatientRepo;

@Controller
public class AdminController {
@Autowired
private AdminRepo admrepos;
@Autowired
private PatientRepo patrepos;
@RequestMapping("/admlogin")
public String alog() {

	return "Alogin";

}

@RequestMapping("/alogin")
public String doclog(@RequestParam("username") String firstname, Model m, @RequestParam("password") String password) {
	radmin r= admrepos.findByFirstnameAndPassword(firstname, password);

	if (!(ObjectUtils.isEmpty(r))) {
		m.addAttribute("successpage", "Login Successful");
		return "successpage";
	}

	return "unsucess";
}
@RequestMapping("/admReg")
public String docreg() {
	return "Aregister";
}
@RequestMapping("/admregister")
public String admreg(Model m, @RequestParam(value = "firstname",defaultValue = "akhil" ) String firstname,
		@RequestParam(value = "lastname",defaultValue = "akhil") String lastname,
		@RequestParam(value = "gender", defaultValue = "female") String gender,
		@RequestParam(value = "contactNo", defaultValue = "45678") Long contactNo,
		@RequestParam(value = "aid", defaultValue = "12") Long aid,
		@RequestParam(value = "pwd", defaultValue = "akhil") String password,
		@RequestParam(value = "email", defaultValue = "akhil") String email) {
	radmin rad=new radmin();
	rad.setAid(aid);
	rad.setContact(contactNo);
	rad.setFirstname(firstname);
	rad.setLastname(lastname);
	rad.setGender(gender);
	rad.setPassword(password);
	rad.setEmail(email);
	admrepos.save(rad);
	m.addAttribute("successpage","Admin Registered Successfully");
	return "successpage";
	
	
}

	
}
