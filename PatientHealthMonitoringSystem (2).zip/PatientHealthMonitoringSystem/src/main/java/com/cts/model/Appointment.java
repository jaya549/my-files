package com.cts.model;



import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class Appointment {
	@Id
	private Long patientid;
	private String doctorname;
	private String patientname;
	private String reason;
	private String time;
	public String getPatientname() {
		return patientname;
	}
	public void setPatientname(String patientname) {
		this.patientname = patientname;
	}
	public Long getPatientid() {
		return patientid;
	}
	public void setPatientid(Long patientid) {
		this.patientid = patientid;
	}
	public String getDoctorname() {
		return doctorname;
	}
	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	@Override
	public String toString() {
		return "Appointment [patientid=" + patientid + ", doctorname=" + doctorname + ", patientname=" + patientname
				+ ", reason=" + reason + ", time=" + time + "]";
	}
	public Appointment(Long patientid, String doctorname, String patientname, String reason, String time) {
		super();
		this.patientid = patientid;
		this.doctorname = doctorname;
		this.patientname = patientname;
		this.reason = reason;
		this.time = time;
	}
	public Appointment() {
		super();
	}
	
	

}
