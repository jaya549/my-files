package com.cts.repos;

import org.springframework.data.repository.CrudRepository;
import com.cts.model.Glucose;

public interface GlucoseRepo extends CrudRepository<Glucose,Integer> {

}
