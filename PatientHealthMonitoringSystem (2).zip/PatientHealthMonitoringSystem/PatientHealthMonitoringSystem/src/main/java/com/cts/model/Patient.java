package com.cts.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Size;



@Entity
public class Patient {
	
	@Id
	private Long patientid;
	private String firstname;
	private String lastname;
	private Date dob;
	private String gender;
	private String contact;
	private String reason;
	private String password;
	private String email;
	private String doctorsqualification;
	private String address;
	
	public Patient() {
		super();
	}
	public Long getPatientid() {
		return patientid;
	}
	public void setPatientid(Long patientid) {
		this.patientid = patientid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDoctorsqualification() {
		return doctorsqualification;
	}
	public void setDoctorsqualification(String doctorsqualification) {
		this.doctorsqualification = doctorsqualification;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Patient(Long patientid, String firstname, String lastname, Date dob, String gender, String contact,
			String reason, String password, String email, String doctorsqualification, String address) {
		super();
		this.patientid = patientid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.dob = dob;
		this.gender = gender;
		this.contact = contact;
		this.reason = reason;
		this.password = password;
		this.email = email;
		this.doctorsqualification = doctorsqualification;
		this.address = address;
	}
	@Override
	public String toString() {
		return "Patient [patientid=" + patientid + ", firstname=" + firstname + ", lastname=" + lastname + ", dob="
				+ dob + ", gender=" + gender + ", contact=" + contact + ", reason=" + reason + ", password=" + password
				+ ", email=" + email + ", doctorsqualification=" + doctorsqualification + ", address=" + address + "]";
	}
}
