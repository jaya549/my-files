package com.cts.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Pressure;
import com.cts.repos.PressureRepo;


@Service
@Transactional
public class PressureService {
	@Autowired
	private PressureRepo presrepos;
	public void register(Pressure pressure) {
		presrepos .save(pressure);
	}
	public List<Pressure> showAll() {
		List<Pressure> patients= (List<Pressure>)presrepos.findAll();
		return patients;
		
	}
}
