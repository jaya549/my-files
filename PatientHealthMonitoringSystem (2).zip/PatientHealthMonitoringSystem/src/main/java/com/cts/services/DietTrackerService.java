package com.cts.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cts.model.Diettracker;

import com.cts.repos.DiettrackRepo;

@Service
@Transactional
public class DietTrackerService {
	@Autowired
	private DiettrackRepo dietrepos;
	public void register(Diettracker diet) {
		dietrepos.save(diet);
	}
	public List<Diettracker> showAll() {
		List<Diettracker> patients= (List<Diettracker>) dietrepos.findAll();
		return patients;
		
	}
}
