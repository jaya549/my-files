package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Blood {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "blood_sequence")
	private int bloodid;
	private Long patientid;
	private String bloodgroup;
	private int rbc;
	private int wbc;
	@ManyToOne
	@JoinColumn(name = "patientid",insertable=false, updatable=false)
	private Patient patient;
	
	public Blood() {
		super();
	}
	public Blood(int bloodid, Long patientid, String bloodgroup, int rbc, int wbc, Patient patient) {
		super();
		this.bloodid = bloodid;
		this.patientid = patientid;
		this.bloodgroup = bloodgroup;
		this.rbc = rbc;
		this.wbc = wbc;
		this.patient = patient;
	}
	@Override
	public String toString() {
		return "Blood [bloodid=" + bloodid + ", patientid=" + patientid + ", bloodgroup=" + bloodgroup + ", rbc=" + rbc
				+ ", wbc=" + wbc + ", patient=" + patient + "]";
	}
	public int getBloodid() {
		return bloodid;
	}
	public void setBloodid(int bloodid) {
		this.bloodid = bloodid;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public int getRbc() {
		return rbc;
	}
	public void setRbc(int rbc) {
		this.rbc = rbc;
	}
	public int getWbc() {
		return wbc;
	}
	public void setWbc(int wbc) {
		this.wbc = wbc;
	}
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	public Long getPatientid() {
		return patientid;
	}
	public void setPatientid(Long patientid) {
		this.patientid = patientid;
	}
	
	
	
	
}
