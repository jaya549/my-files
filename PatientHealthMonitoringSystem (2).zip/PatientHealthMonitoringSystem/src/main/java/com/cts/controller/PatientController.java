package com.cts.controller;


import java.util.List;


import javax.servlet.http.HttpSession;
import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.Activitytracker;
import com.cts.model.Appointment;
import com.cts.model.Blood;
import com.cts.model.Bmi;
import com.cts.model.Caloriestracker;
import com.cts.model.Cholestrol;
import com.cts.model.Diettracker;
import com.cts.model.Glucose;
import com.cts.model.MedicalRecord;
import com.cts.model.Patient;
import com.cts.model.Pressure;
import com.cts.model.Thyroid;

import com.cts.services.ActivityTrackerService;
import com.cts.services.AppointmentService;
import com.cts.services.BloodService;
import com.cts.services.BmiService;
import com.cts.services.CaloriesTrackerService;
import com.cts.services.CholestrolService;
import com.cts.services.DietTrackerService;
import com.cts.services.GlucoseService;
import com.cts.services.MedicalService;
import com.cts.services.PatientService;
import com.cts.services.PressureService;
import com.cts.services.ThyroidService;
@Controller
public class PatientController {
	@Autowired
	private PatientService patientservice;
	@Autowired
	private CaloriesTrackerService caloriesservice;
	@Autowired
	private DietTrackerService dietservice;
	@Autowired
	private AppointmentService  appointmentservice;
	@Autowired
	private GlucoseService glucoseservice;
	@Autowired
	private BloodService bloodservice;
	@Autowired
	private BmiService bmiservice;
	@Autowired
	private ActivityTrackerService activityservice;
	@Autowired
	private CholestrolService cholestrolservice;
	@Autowired
	private PressureService pressureservice;
	@Autowired
	private ThyroidService thyroidservice;
	@Autowired
	private MedicalService medicalservice;
	static Long id;
	static String name;
	@GetMapping("/pregister")
	public String patreg(Model m) {
		Patient patient=new Patient();
		m.addAttribute("patient",patient);
		return "Pregister";
		
	}
	@PostMapping("/pregister")
	public String pare(@Valid @ModelAttribute("patient")  Patient patient,BindingResult br,Model m) {
		if(br.hasErrors()) {
			System.out.println("Errors are present");
			return "Pregister";
		}else {
			//System.out.println("No errors");
			m.addAttribute("successpage","Registered Successfully");
			patientservice.register(patient);
		}
		System.out.println(patient);
		
		return "successpage";
		
	}

	@RequestMapping("/plogin")

	public String log(Model m) {
		m.addAttribute("logindata",new Patient());
		return "patLogin";

	}

	@PostMapping("/plogin")
	public String gnoj(@RequestParam("username") String firstname, Model m, @RequestParam("password") String password,HttpSession session) {
		Patient p = patientservice.findByFirstnameAndPassword(firstname, password);
		if (!(ObjectUtils.isEmpty(p))) {
			id=p.getPatientid();
			name=p.getFirstname();
			session.setAttribute("pid", id);
			session.setAttribute("pname", name);
			name=p.getFirstname();
			m.addAttribute("successpage", "Login Successful");
			return "psuc";
		}
		return "Punsucess";
	}
	@GetMapping("/pforget")
	public String forgetuser() {
		return "patientforgetid";
	}
	@PostMapping("/pforget")
	public String forgetuser(Model m,@RequestParam("question") String question,@RequestParam("answer") String answer) {
		String username=patientservice.findusername(question,answer);
		if(username!=null)
		{
			m.addAttribute("successpage",username);
			return "successpage";
		}
		
			return "Punsucess";
		
	}
	@GetMapping("/pforgetpassword")
	public String forgetpassword() {
		return "patientforgetpassword";
	}
	@PostMapping("/pforgetpassword")
	public String forgetpassword(Model m,@RequestParam("question") String question,@RequestParam("answer") String answer,@RequestParam("contactNo")String contact) {
		String password=patientservice.findpatientpassword(question,answer,contact);
		if(password!=null)
		{
			m.addAttribute("successpage",password);
			return "successpage";
		}
		
			return "Punsucess";
		
	}
	
	@RequestMapping("/bmi")
	public String bmi(HttpSession session, Model m){
		long pid=(long) session.getAttribute("pid");
		Bmi bmi=new Bmi();
		bmi.setPatientid(pid);
		m.addAttribute("bmi",bmi);
		m.addAttribute("id",pid);
		return "bmi";
	}
	@RequestMapping("/bmireg")
	public String bmirec(@Valid@ModelAttribute(value = "bmi") Bmi bmi) {
		bmiservice.register(bmi);
		return "desuc";
	}
	@RequestMapping("/calorieTracker")
	public String cal(HttpSession session, Model m){
		long pid=(long) session.getAttribute("pid");
		Caloriestracker caloriestracker=new Caloriestracker();
		m.addAttribute("caloriestracker",caloriestracker);
		m.addAttribute("id",pid);
		return "calorieTracker";
	}
	@RequestMapping("/calrec")
	public String calrec(@Valid@ModelAttribute(value = "calorietracker") Caloriestracker cal) {
		caloriesservice.register(cal);
		return "desuc";
	}
	@RequestMapping("/glucose")
	public String gluReading(HttpSession session,Model m) {
		long pid=(long) session.getAttribute("pid");
		Glucose glucose=new Glucose();
		m.addAttribute("id",pid);
		m.addAttribute("glucose",glucose);
		System.out.println(glucose);
		return "glucose";
	}
	
	@RequestMapping("/glucoreg")
	public String glurec(@Valid@ModelAttribute(value = "glucose") Glucose glucose) {
		glucoseservice.register(glucose);
		return "desuc";
	}
	
	
	@RequestMapping("/blood")
	public String bldCount(HttpSession session,Model m) {
		long pid=(long) session.getAttribute("pid");
		Blood blood=new Blood();
		m.addAttribute("id",pid);
		m.addAttribute("blood",blood);
		return "bloodcount";
	}
	@RequestMapping("/bloodreg")
	public String blcount(@Valid@ModelAttribute(value = "blood") Blood blood) {
		bloodservice.register(blood);
		return "desuc";
	}
	@RequestMapping("/pressure")
	public String pressure(HttpSession session,Model m) {
		long pid=(long) session.getAttribute("pid");
		Pressure pressure=new Pressure();
		m.addAttribute("id",pid);
		m.addAttribute("pressure",pressure);
		return "pressure";
	}
	@RequestMapping("/prereg")
	public String prcount(@Valid@ModelAttribute(value = "pressure") Pressure pressure) {
		
		pressureservice.register(pressure);
		return "desuc";
	}
	
	@RequestMapping("/cholestrol")
	public String cholestrol(HttpSession session,Model m) {
		long pid=(long) session.getAttribute("pid");
		Cholestrol cholestrol= new Cholestrol();
		m.addAttribute("id",pid);
		m.addAttribute("cholestrol",cholestrol);
		return "cholestrol";
	}
	@RequestMapping("/choreg")
	public String chcount(@Valid@ModelAttribute(value = "cholestrol") Cholestrol cholestrol) {
		
		cholestrolservice.register(cholestrol);
		return "desuc";
	}
	@RequestMapping("/thyroid")
	public String thyroid(HttpSession session,Model m) {
		long pid=(long) session.getAttribute("pid");
		Thyroid thyroid=new Thyroid();
		m.addAttribute("id",pid);
		m.addAttribute("thyroid",thyroid);
		return "thyroid";
	}
	@RequestMapping("/thyreg")
	public String thyreg(@Valid@ModelAttribute(value = "thyroid") Thyroid thyroid){
		thyroidservice.register(thyroid);
		return "desuc";
		
	}
	@RequestMapping("/ActivityTracker")
	public String activity(HttpSession session,Model m) {
		long pid=(long) session.getAttribute("pid");
		Activitytracker activitytracker=new Activitytracker();
		m.addAttribute("id",pid);
		m.addAttribute("activitytracker",activitytracker);
		return "ActivityTracker";
	}
	@RequestMapping("/actreg")
	public String actreg(@Valid@ModelAttribute(value = "activitytracker") Activitytracker activitytracker) {
		activityservice.register(activitytracker);
		return "desuc";
	}
	@RequestMapping("/diettracker")
	public String diet(HttpSession session, Model m) {
		long pid=(long) session.getAttribute("pid");
		Diettracker diettracker=new Diettracker();
		m.addAttribute("diettracker",diettracker);
		m.addAttribute("id",pid);
		return "dietTracker";
	}
	@RequestMapping("/dietreg")
	public String dietcount(@Valid@ModelAttribute(value = "diettracker") Diettracker diet) {
		
		dietservice.register(diet);
		return "desuc";
	}
	@RequestMapping("/patlist")
	public String patlist(Model m) {
		List<Patient> allpatients = patientservice.showAllpatients();
		m.addAttribute("patients",allpatients);
		return "listofpatients";
		
	}
	@RequestMapping("/viewDocRecommendations")
	public String viewDocRecommendations(Model m,HttpSession session) {
		long pid=(long) session.getAttribute("pid");
		MedicalRecord medrec=medicalservice.findByPatientid(pid);
		String text=medrec.getPrescription();
		m.addAttribute("prescription", text);
		return "viewDocRecommendations";
	}
	@RequestMapping("/patient/{patientid}")
	public String updateEmployee(Model model, @PathVariable("patientid")Long id ) {
		Patient p= patientservice.findByPatientid(id);
		model.addAttribute("patient", p);
		return "update";
	}
	@RequestMapping("/updaterec")
	public String recs(Model m,HttpSession session) {
		String doctorname=(String) session.getAttribute("doctorname");
		m.addAttribute("username",doctorname);
		List<MedicalRecord> medrec=  medicalservice.showAll();
		m.addAttribute("appointments",medrec);
		return "updaterecords";
	}
	
	//@RequestMapping("/detail/${patient.patientid}")
	//public String sie(Model m, @PathVariable("patientid")Long id) {
		
	//}
	@RequestMapping("/updatedetails")
	public String update(@ModelAttribute("patient") Patient p,Model m) {
		patientservice.register(p);
		m.addAttribute("successpage","Updated successfully");
		return "successpage";
	}
	@RequestMapping("/psuc")
	public String psuc() {
		return "psuc";
	}
	@RequestMapping("/appoint")
	public String papp(Model m) {
		Appointment app=new Appointment();
		app.setPatientid(id);
		app.setPatientname(name);
		m.addAttribute("app",app);
		return "appointment";
	}
	@RequestMapping("/desuc")
	public String desuc(@Valid@ModelAttribute("app") Appointment app) {
		appointmentservice.register(app);
		return "desuc";
	}
	@RequestMapping("/logoff")
	public String logout(HttpSession session,Model m) {
		
		if(session!=null)
			session.invalidate();
		m.addAttribute("successpage","Loggedout Successfully");
		
		return "successpage";
	}
	
	@RequestMapping("/activityread")
	public String act(Model m,HttpSession session) {
		List<Activitytracker> activitytracker= activityservice.showAll();
		m.addAttribute("activitytracker",activitytracker);
		return "activityrecords";
	}
	@RequestMapping("/bloodread")
	public String bloodread(Model m,HttpSession session) {
		List<Blood> bloodrecords= (List<Blood>) bloodservice.showAll();
		m.addAttribute("bloodrecords",bloodrecords);
		return "bloodrecords";
	}
	@RequestMapping("/glucoseread")
	public String glucoseread(Model m,HttpSession session) {
		List<Glucose> glurec=(List<Glucose>) glucoseservice.showAll();
		m.addAttribute("glurec",glurec);
		return "glucoserecords";
	}
	@RequestMapping("/cholestrolread")
	public String cholesterolread(Model m,HttpSession session) {
		List<Cholestrol> cholestrolrecords=(List<Cholestrol>) cholestrolservice.showAll();
		m.addAttribute("cholestrolrecords",cholestrolrecords);
		return "cholestrolrecords";
	}
	@RequestMapping("/thyroidread")
	public String thyroidread(Model m,HttpSession session) {
		List<Thyroid> thyroidrecords=(List<Thyroid>)thyroidservice.showAll();
		m.addAttribute("thyroidrecords",thyroidrecords);
		return "thyroidrecords";
	}
	@RequestMapping("/dietread")
	public String dietread(Model m,HttpSession session) {
		List<Diettracker> dietrecords=(List<Diettracker>)dietservice.showAll();
		m.addAttribute("dietrecords",dietrecords);
		return "dietrecords";
	}
	@RequestMapping("/caloriesread")
	public String caloriesread(Model m,HttpSession session) {
		List<Caloriestracker> calrecords=caloriesservice.showAll();
		m.addAttribute("calrecords",calrecords);
		return "caloriesrecords";
	}
	@RequestMapping("/presread")
	public String pres(Model m,HttpSession session) {
		List<Pressure> presreadings = (List<Pressure>) pressureservice.showAll();
		m.addAttribute("pressure",presreadings);
		return "presreadings";
	}
	@RequestMapping("/bmiread")
	public String bmiread(Model m,HttpSession session) {
		List<Bmi> bmirec=(List<Bmi>) bmiservice.showAll();
		m.addAttribute("bmirec",bmirec);
		return "bmirecords";
	}
	
}
