package com.cts.model;

import java.sql.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;




@Entity
public class Patient {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "patient_sequence")
	private Long patientid;
	@NotBlank(message = "Please enter your first name")
	private String firstname;
	@NotEmpty(message = "Please enter lastname")
	private String lastname;
	
	private Date dob;
	@NotEmpty
	private String gender;
	@Pattern(regexp = "\\d{10}",message = "mobile number should be 10digits")
	@NotEmpty
	private String contact;
	@NotEmpty
	private String reason;
	@Pattern( message = "password should contain 6 characters and atleast one special character" ,regexp = "^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+])[A-Za-z\\d][A-Za-z\\d!@#$%^&*()_+]{6,19}$")
	private String password;
	@Email(message = "invalid email ")
	@NotEmpty(message = "enter an email")
	private String email;
	@NotEmpty
	private String doctorname;
	
	private String address;
	@NotEmpty
	private String question;
	@NotEmpty
	private String answer;
	
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDoctorname() {
		return doctorname;
	}
	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}
	@OneToMany
	@JoinColumn(name = "patientid")
	private Set<Pressure> pressurereadings;
	
	@OneToMany
	@JoinColumn(name = "patientid")
	private Set<Blood> bloodreadings;
	
	@OneToMany
	@JoinColumn(name = "patientid")
	private Set<Appointment> appointmentreadings;
	@OneToMany
	@JoinColumn(name = "patientid")
	private Set<Glucose> glucosereadings;
	@OneToMany
	@JoinColumn(name = "patientid")
	private Set<Cholestrol> cholestrolreadings;
	@OneToMany
	@JoinColumn(name = "patientid")
	private Set<Thyroid> thyroidreadings;
	@OneToMany
	@JoinColumn(name = "patientid")
	private Set<Diettracker> dietreadings;
	@OneToMany
	@JoinColumn(name = "patientid")
	private Set<Caloriestracker> caloriesreadings;
	@OneToMany
	@JoinColumn(name="patientid")
	private Set<Activitytracker> activityreadings;
	@OneToMany
	@JoinColumn(name="patientid")
	private Set<MedicalRecord> medrecords;
	
	public Set<MedicalRecord> getMedrecords() {
		return medrecords;
	}
	public void setMedrecords(Set<MedicalRecord> medrecords) {
		this.medrecords = medrecords;
	}
	public Long getPatientid() {
		return patientid;
	}
	public void setPatientid(Long patientid) {
		this.patientid = patientid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Set<Pressure> getPressurereadings() {
		return pressurereadings;
	}
	public void setPressurereadings(Set<Pressure> pressurereadings) {
		this.pressurereadings = pressurereadings;
	}
	public Set<Blood> getBloodreadings() {
		return bloodreadings;
	}
	public void setBloodreadings(Set<Blood> bloodreadings) {
		this.bloodreadings = bloodreadings;
	}
	public Set<Appointment> getAppointmentreadings() {
		return appointmentreadings;
	}
	public void setAppointmentreadings(Set<Appointment> appointmentreadings) {
		this.appointmentreadings = appointmentreadings;
	}
	public Set<Glucose> getGlucosereadings() {
		return glucosereadings;
	}
	public void setGlucosereadings(Set<Glucose> glucosereadings) {
		this.glucosereadings = glucosereadings;
	}
	public Set<Cholestrol> getCholestrolreadings() {
		return cholestrolreadings;
	}
	public void setCholestrolreadings(Set<Cholestrol> cholestrolreadings) {
		this.cholestrolreadings = cholestrolreadings;
	}
	public Set<Thyroid> getThyroidreadings() {
		return thyroidreadings;
	}
	public void setThyroidreadings(Set<Thyroid> thyroidreadings) {
		this.thyroidreadings = thyroidreadings;
	}
	public Set<Diettracker> getDietreadings() {
		return dietreadings;
	}
	public void setDietreadings(Set<Diettracker> dietreadings) {
		this.dietreadings = dietreadings;
	}
	public Set<Caloriestracker> getCaloriesreadings() {
		return caloriesreadings;
	}
	public void setCaloriesreadings(Set<Caloriestracker> caloriesreadings) {
		this.caloriesreadings = caloriesreadings;
	}
	public Set<Activitytracker> getActivityreadings() {
		return activityreadings;
	}
	public void setActivityreadings(Set<Activitytracker> activityreadings) {
		this.activityreadings = activityreadings;
	}
	public Patient(Long patientid, @NotBlank(message = "Please enter your first name") String firstname,
			@NotEmpty(message = "Please enter lastname") String lastname, Date dob, @NotEmpty String gender,
			String contact, String reason,
			@Pattern(message = "password should contain 6 characters and atleast one special character", regexp = "^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+])[A-Za-z\\d][A-Za-z\\d!@#$%^&*()_+]{6,19}$") String password,
			@Email(message = "invalid email ") @NotEmpty(message = "enter an email") String email,
			Set<Pressure> pressurereadings, Set<Blood> bloodreadings, Set<Appointment> appointmentreadings,
			Set<Glucose> glucosereadings, Set<Cholestrol> cholestrolreadings, Set<Thyroid> thyroidreadings,
			Set<Diettracker> dietreadings, Set<Caloriestracker> caloriesreadings,
			Set<Activitytracker> activityreadings) {
		super();
		this.patientid = patientid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.dob = dob;
		this.gender = gender;
		this.contact = contact;
		this.reason = reason;
		this.password = password;
		this.email = email;
		this.pressurereadings = pressurereadings;
		this.bloodreadings = bloodreadings;
		this.appointmentreadings = appointmentreadings;
		this.glucosereadings = glucosereadings;
		this.cholestrolreadings = cholestrolreadings;
		this.thyroidreadings = thyroidreadings;
		this.dietreadings = dietreadings;
		this.caloriesreadings = caloriesreadings;
		this.activityreadings = activityreadings;
	}
	public Patient() {
		super();
	}
	@Override
	public String toString() {
		return "Patient [patientid=" + patientid + ", firstname=" + firstname + ", lastname=" + lastname + ", dob="
				+ dob + ", gender=" + gender + ", contact=" + contact + ", reason=" + reason + ", password=" + password
				+ ", email=" + email + ", pressurereadings=" + pressurereadings + ", bloodreadings=" + bloodreadings
				+ ", appointmentreadings=" + appointmentreadings + ", glucosereadings=" + glucosereadings
				+ ", cholestrolreadings=" + cholestrolreadings + ", thyroidreadings=" + thyroidreadings
				+ ", dietreadings=" + dietreadings + ", caloriesreadings=" + caloriesreadings + ", activityreadings="
				+ activityreadings + "]";
	}
	
	

}
