package com.cts.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Activitytracker;

import com.cts.repos.ActivityRepo;

@Service
@Transactional
public class ActivityTrackerService {
	@Autowired
	private ActivityRepo activityrepo;
	public void register(Activitytracker activity) {
		activityrepo .save(activity);
	}
	public List<Activitytracker> showAll() {
		List<Activitytracker> patients= (List<Activitytracker>) activityrepo.findAll();
		return patients;
		
	}
	

}
