package com.cts.controller;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.Patient;
import com.cts.repos.PatientRepo;
@Controller
public class PatientController {
	@Autowired
	private PatientRepo patrepos;
	@RequestMapping({ "/patReg" })
	public String regform(Model m, @RequestParam(value = "fname", defaultValue = "akhil") String firstname,
			@RequestParam(value = "lname", defaultValue = "akhil") String lastname,
			
			@RequestParam(value = "dob", defaultValue = "3") Date dob,
			@RequestParam(value = "email", defaultValue = "df") String email,
			
			@RequestParam(value = "gender", defaultValue = "65") String gender,
			@RequestParam(value = "pid", defaultValue = "2") Long id,
			@RequestParam(value = "add", defaultValue = "ff") String address,
			@RequestParam(value = "reason", defaultValue = "ff") String reason,
			@RequestParam(value = "qualification", defaultValue = "akhil") String doctorsqualification,
			@RequestParam(value = "pwd", defaultValue = "akhil") String password,
			@RequestParam(value = "contact", defaultValue = "234") String contact) {

			Patient p=new Patient();
			p.setAddress(address);
			p.setContact(contact);
			p.setDob(dob);
			p.setDoctorsqualification(doctorsqualification);
			p.setEmail(email);
			p.setFirstname(firstname);
			p.setGender(gender);
			p.setLastname(lastname);
			p.setPassword(password);
			p.setPatientid(id);
			p.setReason(reason);
			patrepos.save(p);
		
		m.addAttribute("successpage", "Patient Registration success");
		return "successpage";

	}

	@RequestMapping("/plogin")

	public String log() {

		return "patLogin";

	}

	@RequestMapping("/patlogin")
	public String gnoj(@RequestParam("name") String firstname, Model m, @RequestParam("password") String password) {
		Patient p = patrepos.findByFirstnameAndPassword(firstname, password);

		if (!(ObjectUtils.isEmpty(p))) {
			m.addAttribute("successpage", "Login Successful");
			return "successpage";
		}

		return "unsucess";
	}

}
