package com.cts.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Blood;

import com.cts.repos.BloodRepo;

@Service
@Transactional
public class BloodService {
	@Autowired
	private BloodRepo bloodrepos;
	public void register(Blood blood) {
		bloodrepos.save(blood);
	}
	public List<Blood> showAll() {
		List<Blood> patients= (List<Blood>) bloodrepos.findAll();
		return patients;
		
	}

}
