package com.cts.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.radmin;

public interface AdminRepo extends CrudRepository<radmin, Long> {
	radmin findByFirstnameAndPassword(String firstname, String password);
	
}
