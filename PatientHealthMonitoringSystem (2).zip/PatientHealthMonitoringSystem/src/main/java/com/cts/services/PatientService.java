package com.cts.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.cts.model.Patient;
import com.cts.repos.PatientRepo;

@Service
@Transactional
public class PatientService {
	@Autowired
	private PatientRepo patrepos;
	public void register(Patient patient) {
		patrepos.save(patient);
	}
	public List<Patient> showAllpatients() {
		List<Patient> patients= (List<Patient>) patrepos.findAll();
		return patients;
		
	}

	public Patient findByFirstnameAndPassword(String firstname,String Password) {
		Patient p= patrepos.findByFirstnameAndPassword(firstname, Password);
		return p;
	}
	public Patient findByPatientid(Long id) {
		Patient p= patrepos.findByPatientid(id);
		return p;
	}
	public String findusername(String question, String answer) {
		Patient p=patrepos.findByQuestionAndAnswer(question,answer);
		if(!(ObjectUtils.isEmpty(p))) {
		return p.getFirstname();
	}
		else {
			return null;
		}
	}
	public String findpatientpassword(String question, String answer, String contact) {
		Patient p=patrepos.findByQuestionAndAnswer(question,answer);
		if(!(ObjectUtils.isEmpty(p))) {
			Patient p2=patrepos.findByContact(contact);
			if(p.equals(p2)) {
				return p.getPassword();
			}
		}
		return null;
	}

}
